# تجهيز EnzoBot للاستضافة

## إعدادات Render
- Service type: Background Worker
- Runtime: Node
- Build Command: `npm install`
- Start Command: `npm start`

## متغيرات البيئة المطلوبة
- `DISCORD_TOKEN`: توكن البوت الجديد من Discord Developer Portal.
- `DISCORD_CLIENT_SECRET`: سر تطبيق Discord الجديد (للوحة التحكم فقط).
- `DASHBOARD_SESSION_SECRET`: سلسلة عشوائية طويلة وسرية.

لا تضع الأسرار داخل ملفات المشروع أو GitHub. اجعل مستودع GitHub خاصاً.

ملاحظة: لوحة التحكم تحتاج عنوان Web Service عام وإعداد OAuth Redirect URI مطابقاً؛ تشغيل البوت كـ Background Worker وحده لا يجعل لوحة التحكم متاحة للعامة.
